let iconButton = document.getElementById("button-icon");
iconButton.addEventListener("click", (() => {
    document.querySelector(".fa-bars").classList.toggle("fa-xmark"), document.querySelector(".responsive-nav").classList.toggle("active")
}));
let linksNav = document.querySelectorAll(".links-normal li .nav-link");
linksNav.forEach((e => {
    e.addEventListener("click", (() => {
        document.querySelector(".active").classList.remove("active"), e.classList.add("active")
    }))
}));
let buttonCounter = document.querySelectorAll(".box-rosary  button");
buttonCounter.forEach((e => {
    e.addEventListener("click", (e => {
        const t = e.currentTarget.classList;
        let n = e.currentTarget.parentElement,
            l = n.firstElementChild.innerText;
        n.getAttribute("id") == n.firstElementChild.dataset.name && (t.contains("edit") ? l++ : l = 0, n.firstElementChild.innerText = l)
    }))
}));